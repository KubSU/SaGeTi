var searchData=
[
  ['color',['Color',['../class_i_background_function.html#adfc678738f638628094814dc7b55d17b',1,'IBackgroundFunction']]]
];
