var searchData=
[
  ['jorfunction',['JorFunction',['../class_jor_function.html',1,'']]]
];
