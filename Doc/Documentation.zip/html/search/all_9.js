var searchData=
[
  ['setfunction',['SetFunction',['../class_c_picture.html#ae52603458e4c8f31a89a54f43f215ac2',1,'CPicture']]],
  ['setgraph',['SetGraph',['../class_c_picture.html#a28351c436fb72a4a6f93e11fa292ec76',1,'CPicture']]]
];
