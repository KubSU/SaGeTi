var searchData=
[
  ['getdata',['GetData',['../class_c_picture.html#aefa76f357a27fee18cea44f09f6aae8b',1,'CPicture']]],
  ['gettransformx',['GetTransformX',['../class_c_move_right_modificator.html#acf47b7df624684d9e1de6a5cff7ec117',1,'CMoveRightModificator::GetTransformX()'],['../class_c_stretch_x_modificator.html#a518de66ed5aef9007cef4854430221a1',1,'CStretchXModificator::GetTransformX()'],['../class_c_rotation_modificator.html#a8685a133e3f7f50dd7f6d32930855f88',1,'CRotationModificator::GetTransformX()'],['../class_i_modificator.html#a177f67d8f8c314c5b92da53a365e275e',1,'IModificator::GetTransformX()']]],
  ['gettransformy',['GetTransformY',['../class_c_move_up_modificator.html#aaafe12d6286db6f479576c6666b4f476',1,'CMoveUpModificator::GetTransformY()'],['../class_c_stretch_y_modificator.html#a8f571cb74f6a98530f2e6a1b90b173f7',1,'CStretchYModificator::GetTransformY()'],['../class_c_rotation_modificator.html#a792cef0a5d126e174f232af3071b90bd',1,'CRotationModificator::GetTransformY()'],['../class_i_modificator.html#a94712d7f9207894834897a1a8d3dd20a',1,'IModificator::GetTransformY()']]]
];
